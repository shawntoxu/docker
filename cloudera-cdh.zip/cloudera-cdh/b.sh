#!/bin/bash 
docker build -t  shawntoxu/cloud-cdh:base  ./